S_CFG = {
    OpeningWebhook = ""
}