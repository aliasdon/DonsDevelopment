# ALW Loot Cases

Well rockstar games decided that I can not sell this script.
Works with ESX/QB core usable items.

# discord.gg/zgEpJHYvdE

![legendary-case](https://github.com/user-attachments/assets/e3cc6374-ffe8-40dc-9978-ed82d27d5e34)
